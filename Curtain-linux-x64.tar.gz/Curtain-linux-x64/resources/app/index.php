<?php 
// allow heroku to detect it as php app while only serving static html
include_once("index.html");
?>
